L2R Streamlit Mini App (Bundle)

This zip contains:
- streamlit_app_l2r_min.py — the Streamlit UI (search, unseen-only filter, color-coded table)
- outputs_l2r/ — expected folder structure with sample CSVs

How to run:
1) pip install streamlit pandas numpy matplotlib
2) streamlit run streamlit_app_l2r_min.py
In the sidebar, point the app to your actual outputs folder (from your pipeline).
Replace the sample CSVs inside outputs_l2r/ with your real ones (same filenames).
